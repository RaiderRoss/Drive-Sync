import { useCallback, useMemo, useState } from "react";
import {
  Badge,
  Breadcrumb,
  Button,
  Card,
  Col,
  ConfigProvider,
  Descriptions,
  Divider,
  Input,
  Progress,
  Row,
  Statistic,
  Table,
  Tag,
  Typography,
  theme,
} from "antd";
import type { TableColumnsType, ThemeConfig } from "antd";
import {
  ArrowLeftOutlined,
  EllipsisOutlined,
  FileOutlined,
  FolderFilled,
  ReloadOutlined,
  SearchOutlined,
} from "@ant-design/icons";
import Canvas, { colorFor, formatBytes } from "./canvas";
import type { FsNode } from "./canvas";

const { Title, Text } = Typography;

/* ───────────────────────────── Demo data ───────────────────────────── */

const MB = 1024 ** 2;
const GB = 1024 ** 3;
const TB = 1024 ** 4;

const file = (id: string, name: string, size: number, extension: string): FsNode => ({
  id, name, kind: "file", size, extension, modified: "Today",
});

const dir = (id: string, name: string, size: number, children: FsNode[]): FsNode => ({
  id, name, kind: "directory", size, children, modified: "Today",
});

const FILESYSTEM: FsNode = dir("root", "C:", 1.42 * TB, [
  dir("windows", "Windows", 68 * GB, [
    dir("system32", "System32", 31 * GB, [
      file("kernel", "kernel.dll", 780 * MB, "dll"),
      file("drivers", "drivers.cab", 1.2 * GB, "cab"),
      file("sys-cache", "component-store.bin", 2.4 * GB, "bin"),
    ]),
    dir("winsxs", "WinSxS", 29 * GB, [
      file("winsxs-manifest", "manifests.bin", 4.1 * GB, "bin"),
      file("winsxs-cache", "component-cache.dat", 2.3 * GB, "dat"),
    ]),
    file("win-log", "setup.log", 18 * MB, "log"),
  ]),
  dir("users", "Users", 182 * GB, [
    dir("ross", "Ross", 182 * GB, [
      dir("documents", "Documents", 12 * GB, [
        file("report", "research-report.pdf", 84 * MB, "pdf"),
        file("notes", "notes.md", 2 * MB, "md"),
        file("archive-docs", "archive.zip", 2.8 * GB, "zip"),
      ]),
      dir("downloads", "Downloads", 45 * GB, [
        file("installer", "installer.iso", 6.2 * GB, "iso"),
        file("dataset", "dataset.tar", 4.6 * GB, "tar"),
        file("video-download", "recording.mp4", 2.1 * GB, "mp4"),
        file("old-archive", "old-backup.zip", 8.4 * GB, "zip"),
      ]),
      dir("projects", "Projects", 82 * GB, [
        dir("rust", "Rust", 32 * GB, [
          file("rust-build", "target-cache.bin", 8.2 * GB, "bin"),
          file("rust-project", "diskvision-source.zip", 1.4 * GB, "zip"),
          file("rust-db", "index.sqlite", 640 * MB, "sqlite"),
        ]),
        dir("react", "React", 24 * GB, [
          file("react-build", "build-cache.tar", 4.8 * GB, "tar"),
          file("react-assets", "assets.bundle", 1.1 * GB, "bundle"),
        ]),
        dir("graphics", "Graphics", 8 * GB, [
          file("texture-pack", "textures.pack", 3.2 * GB, "pack"),
          file("render", "render-output.mp4", 2.1 * GB, "mp4"),
        ]),
        file("project-backup", "project-backup.zip", 4.8 * GB, "zip"),
        file("project-db", "projects.sqlite", 820 * MB, "sqlite"),
      ]),
      dir("videos", "Videos", 38 * GB, [
        file("video-one", "conference.mp4", 12 * GB, "mp4"),
        file("video-two", "capture.mkv", 8.6 * GB, "mkv"),
        file("video-three", "tutorial.mp4", 4.2 * GB, "mp4"),
      ]),
      file("profile", "profile.json", 24 * MB, "json"),
    ]),
    dir("public", "Public", 4 * GB, [
      file("public-video", "shared-video.mp4", 1.4 * GB, "mp4"),
    ]),
    dir("default", "Default", 1 * GB, [
      file("default-config", "settings.json", 4 * MB, "json"),
    ]),
  ]),
  dir("program-files", "Program Files", 65 * GB, [
    dir("apps", "Applications", 42 * GB, [
      file("app-one", "application.exe", 1.8 * GB, "exe"),
      file("app-two", "resources.pak", 920 * MB, "pak"),
    ]),
    dir("common", "Common Files", 18 * GB, [
      file("common-dll", "shared-runtime.dll", 220 * MB, "dll"),
    ]),
  ]),
  dir("games", "Games", 420 * GB, [
    dir("game-one", "Game Alpha", 180 * GB, [
      file("game-assets", "assets.bundle", 74 * GB, "bundle"),
      file("game-data", "world-data.bin", 32 * GB, "bin"),
    ]),
    dir("game-two", "Game Beta", 120 * GB, [
      file("game-two-data", "game-data.pak", 42 * GB, "pak"),
    ]),
    file("games-library", "library-backup.zip", 16 * GB, "zip"),
  ]),
  dir("program-data", "ProgramData", 22 * GB, [
    file("program-cache", "application-cache.dat", 4.2 * GB, "dat"),
    file("program-log", "system.log", 120 * MB, "log"),
  ]),
]);

const INITIAL_SELECTED_ID = "users";

/* ───────────────────────────── Tree helpers ───────────────────────────── */

function findNode(root: FsNode, id: string): FsNode | undefined {
  if (root.id === id) return root;
  for (const child of root.children ?? []) {
    const found = findNode(child, id);
    if (found) return found;
  }
  return undefined;
}

/** Root → … → node, or undefined if `id` is not in the tree. */
function findPath(root: FsNode, id: string, path: FsNode[] = []): FsNode[] | undefined {
  const next = [...path, root];
  if (root.id === id) return next;
  for (const child of root.children ?? []) {
    const found = findPath(child, id, next);
    if (found) return found;
  }
  return undefined;
}

/* ───────────────────── antd theme driven by index.css tokens ───────────────────── */

/** Resolves the CSS tokens in index.css to concrete colours (antd's algorithms can't take var()). */
function buildAntdTheme(): ThemeConfig {
  const root = getComputedStyle(document.documentElement);
  const token = (name: string, fallback: string) => root.getPropertyValue(name).trim() || fallback;

  return {
    algorithm: theme.darkAlgorithm,
    token: {
      colorPrimary: token("--accent-color", "#0078d4"),
      colorBgBase: token("--bg-primary", "#1c1c1c"),
      colorBgContainer: token("--bg-secondary", "#252525"),
      colorBgElevated: token("--bg-hover", "#2d2d2d"),
      colorTextBase: token("--text-primary", "#ffffff"),
      colorTextSecondary: token("--text-secondary", "#b3b3b3"),
      colorBorder: token("--border-color", "#2d2d2d"),
      colorBorderSecondary: token("--border-color", "#2d2d2d"),
      fontFamily: getComputedStyle(document.body).fontFamily,
      fontSize: 14,
      borderRadius: 4,
      borderRadiusLG: 8,
    },
  };
}

/* ───────────────────────────── Small pieces ───────────────────────────── */

function NodeIcon({ node }: { node: FsNode }) {
  const Icon = node.kind === "directory" ? FolderFilled : node.kind === "cluster" ? EllipsisOutlined : FileOutlined;
  return <Icon style={{ color: colorFor(node) }} />;
}

const CONTENT_COLUMNS: TableColumnsType<FsNode> = [
  {
    key: "name",
    dataIndex: "name",
    render: (_, node) => (
      <span className="dv-entry">
        <NodeIcon node={node} />
        <Text ellipsis>{node.name}</Text>
      </span>
    ),
  },
  {
    key: "size",
    dataIndex: "size",
    align: "right",
    width: 92,
    render: (size: number) => <Text type="secondary">{formatBytes(size)}</Text>,
  },
];

/* ───────────────────────────── Page ───────────────────────────── */

function Explorer() {
  const [focusId, setFocusId] = useState(FILESYSTEM.id);
  const [selectedId, setSelectedId] = useState(INITIAL_SELECTED_ID);
  const [query, setQuery] = useState("");

  const focus = useMemo(() => findNode(FILESYSTEM, focusId) ?? FILESYSTEM, [focusId]);
  // Clicking the "+N more" cluster selects an id that isn't in the tree, so fall back to the focus.
  const selected = useMemo(() => findNode(FILESYSTEM, selectedId) ?? focus, [selectedId, focus]);
  const path = useMemo(() => findPath(FILESYSTEM, focusId) ?? [FILESYSTEM], [focusId]);

  const children = useMemo(() => focus.children ?? [], [focus]);
  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return children.filter(child => child.name.toLowerCase().includes(needle));
  }, [children, query]);
  const largestFiles = useMemo(
    () => children.filter(child => child.kind === "file").sort((a, b) => b.size - a.size).slice(0, 3),
    [children],
  );

  const select = useCallback((node: FsNode) => setSelectedId(node.id), []);

  const navigateTo = useCallback((node: FsNode) => {
    if (node.kind !== "directory") return;
    setFocusId(node.id);
    setSelectedId(node.id);
    setQuery("");
  }, []);

  const goBack = () => {
    if (path.length > 1) navigateTo(path[path.length - 2]);
  };

  const reset = () => {
    setFocusId(FILESYSTEM.id);
    setSelectedId(FILESYSTEM.id);
    setQuery("");
  };

  const breadcrumbItems = path.map((node, index) => ({
    key: node.id,
    title:
      index === path.length - 1 ? (
        node.name
      ) : (
        <a href="#" onClick={event => { event.preventDefault(); navigateTo(node); }}>
          {node.name}
        </a>
      ),
  }));

  return (
    <main className="dv-page">
      <header className="dv-header">
        <div>
          <Title level={1} className="dv-title">DiskVision</Title>
          <Text type="secondary">Explore your storage spatially · Double-click a directory to focus</Text>
        </div>
        <Badge status="success" text="Prototype · Indexed" />
      </header>

      <div className="dv-toolbar">
        <Breadcrumb items={breadcrumbItems} />
        <div className="dv-toolbar__actions">
          <Button icon={<ArrowLeftOutlined />} onClick={goBack} disabled={path.length <= 1}>
            Parent directory
          </Button>
          <Button icon={<ReloadOutlined />} onClick={reset}>Reset view</Button>
        </div>
      </div>

      <Row gutter={[16, 16]}>
        <Col xs={24} sm={8}>
          <Card size="small"><Statistic className="dv-stat" title="Focal directory" value={focus.name} /></Card>
        </Col>
        <Col xs={24} sm={8}>
          <Card size="small"><Statistic className="dv-stat" title="Storage consumption" value={formatBytes(focus.size)} /></Card>
        </Col>
        <Col xs={24} sm={8}>
          <Card size="small"><Statistic className="dv-stat" title="Direct children" value={children.length} /></Card>
        </Col>
      </Row>

      <Row gutter={[16, 16]}>
        <Col xs={24} lg={16}>
          <div className="dv-canvas-panel">
            <Canvas focus={focus} onSelect={select} onNavigate={navigateTo} />
          </div>
        </Col>

        <Col xs={24} lg={8}>
          <Card className="dv-inspector" title={
            <span className="dv-entry">
              <NodeIcon node={selected} />
              <Text strong ellipsis>{selected.name}</Text>
            </span>
          }>
            <Title level={2} className="dv-size">{formatBytes(selected.size)}</Title>
            <Text type="secondary">{selected.kind === "directory" ? "Directory storage consumption" : "File size"}</Text>

            <Descriptions
              className="dv-descriptions"
              size="small"
              colon={false}
              column={1}
              items={[
                { key: "type", label: "Type", children: <Tag>{selected.kind}</Tag> },
                { key: "items", label: "Files / children", children: selected.children?.length ?? (selected.kind === "file" ? "1 file" : "—") },
                { key: "modified", label: "Last modified", children: selected.modified ?? "Unknown" },
                { key: "ext", label: "Extension", children: selected.extension ? `.${selected.extension}` : "—" },
              ]}
            />

            <Divider />
            <Title level={5} className="dv-section">Directory contents</Title>
            <Input
              allowClear
              value={query}
              onChange={event => setQuery(event.target.value)}
              prefix={<SearchOutlined />}
              placeholder="Filter direct children…"
            />
            <Table<FsNode>
              className="dv-contents"
              size="small"
              rowKey="id"
              // FsNode has a `children` field, which antd would otherwise render as expandable tree rows.
              childrenColumnName="__none__"
              showHeader={false}
              pagination={false}
              tableLayout="fixed"
              scroll={{ y: 220 }}
              columns={CONTENT_COLUMNS}
              dataSource={filtered}
              locale={{ emptyText: "No matching direct children." }}
              rowClassName={node => (node.id === selected.id ? "dv-row dv-row--selected" : "dv-row")}
              onRow={node => ({ onClick: () => select(node), onDoubleClick: () => navigateTo(node) })}
            />

            <Divider />
            <Title level={5} className="dv-section">Largest direct files</Title>
            {largestFiles.length ? (
              largestFiles.map(item => (
                <div className="dv-largest" key={item.id}>
                  <div className="dv-largest__row">
                    <Text ellipsis>{item.name}</Text>
                    <Text type="secondary">{formatBytes(item.size)}</Text>
                  </div>
                  <Progress
                    percent={Math.min(100, (item.size / focus.size) * 100)}
                    showInfo={false}
                    size="small"
                    strokeColor={colorFor(item)}
                  />
                </div>
              ))
            ) : (
              <Text type="secondary">No direct files in this directory.</Text>
            )}
          </Card>
        </Col>
      </Row>
    </main>
  );
}

export default function Page() {
  const antdTheme = useMemo(buildAntdTheme, []);
  return (
    <ConfigProvider theme={antdTheme}>
      <Explorer />
    </ConfigProvider>
  );
}
