/**
 * Everything visualization-related for DiskVision lives in this file:
 * data types, colour palette, orbital layout, the 2D canvas renderer, and the
 * <Canvas /> component that wires pan / zoom / click / double-click to it.
 *
 * The canvas takes its colours from the CSS tokens in index.css (--bg-secondary,
 * --text-primary, --text-secondary, --accent-color).
 */
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { CSSProperties, MouseEvent as ReactMouseEvent, PointerEvent as ReactPointerEvent } from "react";
import { Button, Tooltip, Typography } from "antd";
import { AimOutlined, ZoomInOutlined, ZoomOutOutlined } from "@ant-design/icons";

const { Text } = Typography;

/* ───────────────────────────── Types ───────────────────────────── */

export type NodeKind = "directory" | "file" | "cluster";

export interface FsNode {
  id: string;
  name: string;
  kind: NodeKind;
  size: number;
  modified?: string;
  extension?: string;
  children?: FsNode[];
}

interface Point {
  x: number;
  y: number;
}

interface PositionedNode {
  node: FsNode;
  x: number;
  y: number;
  radius: number;
  color: string;
}

interface Scene {
  focus: FsNode;
  nodes: PositionedNode[];
  /** Radius of the outer orbit ring, in scene units. */
  orbitRadius: number;
}

/* ─────────────────────────── Constants ─────────────────────────── */

const MIN_ZOOM = 0.55;
const MAX_ZOOM = 2.4;
/** Children beyond this many collapse into one "+N more" cluster node. */
const MAX_VISIBLE_NODES = 22;
const FOCUS_RADIUS = 35;
const FOCUS_HIT_RADIUS = 39;
const GRID_SIZE = 28;

const KB = 1024;
const MB = KB ** 2;
const GB = KB ** 3;
const TB = KB ** 4;

const clampZoom = (zoom: number) => Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, zoom));

/* ───────────────────────── Formatting & colours ───────────────────────── */

export function formatBytes(bytes: number): string {
  if (bytes >= TB) return `${(bytes / TB).toFixed(2)} TB`;
  if (bytes >= GB) return `${(bytes / GB).toFixed(1)} GB`;
  if (bytes >= MB) return `${(bytes / MB).toFixed(0)} MB`;
  return `${(bytes / KB).toFixed(0)} KB`;
}

/** Mid-tone colours that read well on the dark canvas. */
const PALETTE = {
  directory: "#f59e0b",
  archive: "#ec4899",
  media: "#3b82f6",
  document: "#14b8a6",
  code: "#22c55e",
  system: "#94a3b8",
  cluster: "#94a3b8",
} as const;

const ARCHIVE_EXTENSIONS = new Set(["zip", "tar", "iso", "cab", "pack", "pak", "bundle"]);
const MEDIA_EXTENSIONS = new Set(["mp4", "mkv", "mov", "mp3"]);
const DOCUMENT_EXTENSIONS = new Set(["pdf", "doc", "md", "txt"]);
const CODE_EXTENSIONS = new Set(["rs", "tsx", "ts", "js", "jsx", "json", "sqlite"]);

export function colorFor(node: FsNode): string {
  if (node.kind === "cluster") return PALETTE.cluster;
  if (node.kind === "directory") return PALETTE.directory;
  const ext = (node.extension ?? "").toLowerCase();
  if (ARCHIVE_EXTENSIONS.has(ext)) return PALETTE.archive;
  if (MEDIA_EXTENSIONS.has(ext)) return PALETTE.media;
  if (DOCUMENT_EXTENSIONS.has(ext)) return PALETTE.document;
  if (CODE_EXTENSIONS.has(ext)) return PALETTE.code;
  return PALETTE.system;
}

/** Parses #rgb / #rrggbb; null for anything else. */
function parseHex(color: string): { r: number; g: number; b: number } | null {
  const match = color.trim().match(/^#([0-9a-f]{3}|[0-9a-f]{6})$/i);
  if (!match) return null;
  let hex = match[1];
  if (hex.length === 3) hex = hex.split("").map(c => c + c).join("");
  const n = parseInt(hex, 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

/** `color` as rgba() at `alpha`; unparseable colours are returned unchanged. */
function withAlpha(color: string, alpha: number): string {
  const c = parseHex(color);
  return c ? `rgba(${c.r}, ${c.g}, ${c.b}, ${alpha})` : color;
}

/** Linear mix, amount 0 → a, 1 → b; unparseable input returns `a`. */
function mixColors(a: string, b: string, amount: number): string {
  const ca = parseHex(a);
  const cb = parseHex(b);
  if (!ca || !cb) return a;
  const mix = (from: number, to: number) => Math.round(from + (to - from) * amount);
  return `rgb(${mix(ca.r, cb.r)}, ${mix(ca.g, cb.g)}, ${mix(ca.b, cb.b)})`;
}

/* ─────────────────────────── Canvas theme ─────────────────────────── */

interface CanvasTheme {
  fontFamily: string;
  background: string;
  grid: string;
  ring: string;
  ringOuter: string;
  haloInner: string;
  haloOuter: string;
  focusFill: string;
  focusStroke: string;
  focusInnerRing: string;
  focusLabel: string;
  nodeLabel: string;
  nodeSublabel: string;
}

const TOKEN_FALLBACKS = {
  "--bg-secondary": "#252525",
  "--text-primary": "#ffffff",
  "--text-secondary": "#b3b3b3",
  "--accent-color": "#0078d4",
} as const;

function readTheme(element: HTMLElement): CanvasTheme {
  const style = getComputedStyle(element);
  const token = (name: keyof typeof TOKEN_FALLBACKS) =>
    style.getPropertyValue(name).trim() || TOKEN_FALLBACKS[name];

  const surface = token("--bg-secondary");
  const text = token("--text-secondary");
  const heading = token("--text-primary");
  const accent = token("--accent-color");

  return {
    fontFamily: style.fontFamily || "system-ui, sans-serif",
    background: surface,
    grid: withAlpha(text, 0.09),
    ring: withAlpha(text, 0.2),
    ringOuter: withAlpha(text, 0.32),
    haloInner: withAlpha(accent, 0.3),
    haloOuter: withAlpha(accent, 0),
    focusFill: mixColors(surface, accent, 0.2),
    focusStroke: accent,
    focusInnerRing: withAlpha(accent, 0.4),
    focusLabel: heading,
    nodeLabel: heading,
    nodeSublabel: text,
  };
}

/* ─────────────────────────── Orbital layout ─────────────────────────── */

function orbitRadiusFor(width: number, height: number): number {
  return Math.max(130, Math.min(width, height) * 0.34);
}

/** Positions the focal node's immediate children on an orbit around it. */
function createOrbitalScene(focus: FsNode, width: number, height: number): Scene {
  const orbitRadius = orbitRadiusFor(width, height);
  const children = focus.children ?? [];
  const visible = children.slice(0, MAX_VISIBLE_NODES);
  const overflow = children.length - visible.length;

  const nodes: PositionedNode[] = visible.map((node, index) => {
    const angle = -Math.PI / 2 + (index / Math.max(visible.length, 1)) * Math.PI * 2;
    const distance = orbitRadius * (visible.length > 10 ? 0.9 : 0.82);
    const magnitude = Math.log2(Math.max(node.size / GB, 0.02) + 1);
    const radius = node.kind === "directory"
      ? Math.max(13, Math.min(31, 12 + magnitude * 3))
      : Math.max(5, Math.min(13, 5 + magnitude * 1.3));
    return {
      node,
      x: Math.cos(angle) * distance,
      y: Math.sin(angle) * distance,
      radius,
      color: colorFor(node),
    };
  });

  if (overflow > 0) {
    nodes.push({
      node: {
        id: `${focus.id}-more`,
        name: `+${overflow} more`,
        kind: "cluster",
        size: children.slice(MAX_VISIBLE_NODES).reduce((sum, item) => sum + item.size, 0),
      },
      x: 0,
      y: orbitRadius,
      radius: 17,
      color: PALETTE.cluster,
    });
  }

  return { focus, nodes, orbitRadius };
}

/* ───────────────────────────── Renderer ───────────────────────────── */

class CanvasRenderer {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private theme: CanvasTheme;
  private scene: Scene | null = null;
  private zoom = 1;
  private pan: Point = { x: 0, y: 0 };
  private dpr = 1;

  constructor(canvas: HTMLCanvasElement) {
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("Canvas 2D context is unavailable.");
    this.canvas = canvas;
    this.ctx = ctx;
    this.theme = readTheme(canvas);
  }

  /** Sets scene + view transform and redraws once. */
  update(scene: Scene, zoom: number, pan: Point) {
    this.scene = scene;
    this.zoom = clampZoom(zoom);
    this.pan = pan;
    this.draw();
  }

  resize(width: number, height: number) {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    this.canvas.width = Math.max(1, Math.floor(width * this.dpr));
    this.canvas.height = Math.max(1, Math.floor(height * this.dpr));
    this.draw();
  }

  hitTest(clientX: number, clientY: number): FsNode | null {
    if (!this.scene) return null;
    const rect = this.canvas.getBoundingClientRect();
    const x = (clientX - rect.left - rect.width / 2 - this.pan.x) / this.zoom;
    const y = (clientY - rect.top - rect.height / 2 - this.pan.y) / this.zoom;

    for (let i = this.scene.nodes.length - 1; i >= 0; i--) {
      const item = this.scene.nodes[i];
      if (Math.hypot(x - item.x, y - item.y) <= item.radius + 8) return item.node;
    }
    return Math.hypot(x, y) <= FOCUS_HIT_RADIUS ? this.scene.focus : null;
  }

  draw() {
    const scene = this.scene;
    if (!scene) return;
    const { ctx, canvas, theme } = this;
    const w = canvas.width;
    const h = canvas.height;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, w, h);
    ctx.fillStyle = theme.background;
    ctx.fillRect(0, 0, w, h);
    ctx.scale(this.dpr, this.dpr);

    const width = w / this.dpr;
    const height = h / this.dpr;
    const cx = width / 2 + this.pan.x;
    const cy = height / 2 + this.pan.y;

    this.drawGrid(width, height, cx, cy);

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(this.zoom, this.zoom);
    this.drawOrbits(scene.orbitRadius);
    this.drawConnections(scene);
    this.drawFocus(scene.focus);
    this.drawNodes(scene);
    ctx.restore();
  }

  private drawGrid(width: number, height: number, cx: number, cy: number) {
    const { ctx, theme } = this;
    ctx.save();
    ctx.strokeStyle = theme.grid;
    ctx.lineWidth = 1;
    for (let x = cx % GRID_SIZE; x < width; x += GRID_SIZE) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke();
    }
    for (let y = cy % GRID_SIZE; y < height; y += GRID_SIZE) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke();
    }
    ctx.restore();
  }

  private drawOrbits(orbitRadius: number) {
    const { ctx, theme } = this;
    [0.34, 0.66, 1].forEach((factor, index) => {
      ctx.beginPath();
      ctx.arc(0, 0, orbitRadius * factor, 0, Math.PI * 2);
      ctx.strokeStyle = index === 2 ? theme.ringOuter : theme.ring;
      ctx.lineWidth = 1;
      ctx.setLineDash(index === 1 ? [3, 7] : []);
      ctx.stroke();
    });
    ctx.setLineDash([]);
  }

  /** Drawn behind the nodes. */
  private drawConnections(scene: Scene) {
    const { ctx } = this;
    for (const item of scene.nodes) {
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.quadraticCurveTo(
        item.x * 0.46 + item.y * 0.08,
        item.y * 0.46 - item.x * 0.08,
        item.x,
        item.y,
      );
      ctx.strokeStyle = withAlpha(item.color, 0.53);
      ctx.lineWidth = item.node.kind === "directory" ? 2 : 1;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(item.x * 0.55, item.y * 0.55, 2, 0, Math.PI * 2);
      ctx.fillStyle = item.color;
      ctx.globalAlpha = 0.65;
      ctx.fill();
      ctx.globalAlpha = 1;
    }
  }

  private drawFocus(focus: FsNode) {
    const { ctx, theme } = this;

    const halo = ctx.createRadialGradient(0, 0, 12, 0, 0, 58);
    halo.addColorStop(0, theme.haloInner);
    halo.addColorStop(1, theme.haloOuter);
    ctx.fillStyle = halo;
    ctx.beginPath(); ctx.arc(0, 0, 58, 0, Math.PI * 2); ctx.fill();

    ctx.beginPath();
    ctx.arc(0, 0, FOCUS_RADIUS, 0, Math.PI * 2);
    ctx.fillStyle = theme.focusFill;
    ctx.fill();
    ctx.strokeStyle = theme.focusStroke;
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(0, 0, 26, 0, Math.PI * 2);
    ctx.strokeStyle = theme.focusInnerRing;
    ctx.lineWidth = 1;
    ctx.stroke();

    ctx.fillStyle = theme.focusLabel;
    ctx.font = `600 11px ${theme.fontFamily}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(focus.name, 0, 1);
  }

  private drawNodes(scene: Scene) {
    const { ctx, theme } = this;
    for (const { node, x, y, radius, color } of scene.nodes) {
      ctx.beginPath();
      ctx.arc(x, y, radius + 6, 0, Math.PI * 2);
      ctx.fillStyle = withAlpha(color, 0.1);
      ctx.fill();

      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = withAlpha(color, 0.22);
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = node.kind === "directory" ? 1.8 : 1.2;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(x, y, Math.max(2, radius * 0.24), 0, Math.PI * 2);
      ctx.fillStyle = color;
      ctx.fill();

      const label = node.name.length > 18 ? `${node.name.slice(0, 16)}…` : node.name;
      const labelX = x + (x < 0 ? -radius - 9 : radius + 9);
      ctx.textAlign = x < 0 ? "right" : "left";
      ctx.textBaseline = "middle";
      ctx.font = `12px ${theme.fontFamily}`;
      ctx.fillStyle = theme.nodeLabel;
      ctx.fillText(label, labelX, y - 5);
      ctx.font = `10px ${theme.fontFamily}`;
      ctx.fillStyle = theme.nodeSublabel;
      ctx.fillText(formatBytes(node.size), labelX, y + 9);
    }
  }
}

/* ───────────────────────────── Component ───────────────────────────── */

interface CanvasProps {
  /** The directory shown in the middle; its direct children orbit around it. */
  focus: FsNode;
  /** Single click on a node (or on the focal node). */
  onSelect: (node: FsNode) => void;
  /** Double click on a directory. */
  onNavigate: (node: FsNode) => void;
  style?: CSSProperties;
}

const hudStyle: CSSProperties = {
  position: "absolute",
  top: 12,
  fontSize: 11,
  letterSpacing: 1,
  textTransform: "uppercase",
  pointerEvents: "none",
};

export default function Canvas({ focus, onSelect, onNavigate, style }: CanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const rendererRef = useRef<CanvasRenderer | null>(null);
  const dragRef = useRef<{ x: number; y: number; panX: number; panY: number; moved: boolean } | null>(null);

  const [size, setSize] = useState({ width: 700, height: 480 });
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState<Point>({ x: 0, y: 0 });
  const [panning, setPanning] = useState(false);

  // Re-centre whenever the focal directory changes (state adjusted during render, per React docs).
  const [viewFocusId, setViewFocusId] = useState(focus.id);
  if (viewFocusId !== focus.id) {
    setViewFocusId(focus.id);
    setZoom(1);
    setPan({ x: 0, y: 0 });
  }

  const scene = useMemo(
    () => createOrbitalScene(focus, size.width, size.height),
    [focus, size.width, size.height],
  );

  const zoomBy = useCallback((factor: number) => setZoom(z => clampZoom(z * factor)), []);
  const resetView = useCallback(() => { setZoom(1); setPan({ x: 0, y: 0 }); }, []);

  // Renderer lifecycle: create it and follow the container size.
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const renderer = new CanvasRenderer(canvas);
    rendererRef.current = renderer;

    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      renderer.resize(rect.width, rect.height);
      setSize(current =>
        current.width === rect.width && current.height === rect.height
          ? current
          : { width: rect.width, height: rect.height },
      );
    };
    const observer = new ResizeObserver(resize);
    observer.observe(wrap);
    resize();

    return () => {
      observer.disconnect();
      rendererRef.current = null;
    };
  }, []);

  useEffect(() => {
    rendererRef.current?.update(scene, zoom, pan);
  }, [scene, zoom, pan]);

  // React attaches wheel listeners as passive, so preventDefault (stop page scroll) needs a native one.
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const onWheel = (event: WheelEvent) => {
      event.preventDefault();
      zoomBy(event.deltaY < 0 ? 1.1 : 0.9);
    };
    canvas.addEventListener("wheel", onWheel, { passive: false });
    return () => canvas.removeEventListener("wheel", onWheel);
  }, [zoomBy]);

  const handlePointerDown = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    dragRef.current = { x: event.clientX, y: event.clientY, panX: pan.x, panY: pan.y, moved: false };
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const handlePointerMove = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const drag = dragRef.current;
    if (!drag) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    if (!drag.moved && Math.abs(dx) + Math.abs(dy) > 3) {
      drag.moved = true;
      setPanning(true);
    }
    if (drag.moved) setPan({ x: drag.panX + dx, y: drag.panY + dy });
  };

  const endDrag = () => {
    dragRef.current = null;
    setPanning(false);
  };

  const handlePointerUp = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const drag = dragRef.current;
    if (!drag) return;
    if (!drag.moved) {
      const hit = rendererRef.current?.hitTest(event.clientX, event.clientY);
      if (hit) onSelect(hit);
    }
    endDrag();
  };

  const handleDoubleClick = (event: ReactMouseEvent<HTMLCanvasElement>) => {
    const hit = rendererRef.current?.hitTest(event.clientX, event.clientY);
    if (hit?.kind === "directory") onNavigate(hit);
  };

  return (
    <div
      ref={wrapRef}
      style={{ position: "relative", width: "100%", height: "100%", overflow: "hidden", background: "var(--bg-secondary)", ...style }}
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerCancel={endDrag}
        onDoubleClick={handleDoubleClick}
        aria-label="Interactive radial filesystem visualisation"
        style={{ position: "absolute", inset: 0, display: "block", width: "100%", height: "100%", touchAction: "none", cursor: panning ? "grabbing" : "grab" }}
      />

      <Text type="secondary" style={{ ...hudStyle, left: 14 }}>Direct children</Text>
      <Text type="secondary" style={{ ...hudStyle, right: 14 }}>{scene.nodes.length} visible nodes</Text>
      <Text type="secondary" style={{ position: "absolute", left: 14, bottom: 14, fontSize: 11, pointerEvents: "none" }}>
        Drag to pan · Scroll to zoom · Double-click a directory to focus
      </Text>

      <div style={{ position: "absolute", right: 12, bottom: 12, display: "flex", gap: 6 }}>
        <Tooltip title="Zoom out"><Button size="small" aria-label="Zoom out" icon={<ZoomOutOutlined />} onClick={() => zoomBy(0.85)} /></Tooltip>
        <Tooltip title="Reset zoom and pan"><Button size="small" aria-label="Reset zoom" icon={<AimOutlined />} onClick={resetView} /></Tooltip>
        <Tooltip title="Zoom in"><Button size="small" aria-label="Zoom in" icon={<ZoomInOutlined />} onClick={() => zoomBy(1.15)} /></Tooltip>
      </div>
    </div>
  );
}
